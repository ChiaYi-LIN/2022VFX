# Directory (make sure to get into code directory)
```shell
cd code
```

# Environments
```shell
conda env create -n <env> -f environment.yaml
```

# Run program
```python
python main.py
```