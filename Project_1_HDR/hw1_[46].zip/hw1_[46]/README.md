# Environments
```shell
conda env create -n <env> -f ./code/environment.yaml
```

# Run program
```python
python ./code/main.py
```