# Environment
in /
```shell
cd code
conda env create -n vfx_project_2 -f ./environment.yml
conda activate vfx_project_2
```

# Image Stitching
in code/
```shel
python image_stitching.py
```