# Environment
```shell
cd code
conda env create --vfx_project_2 --file=environments.yml
conda activate vfx_project_2
cd ..
```

# Image Stitching
```shel
python image_stitching.py
```